# Taverna del Gentilorco - TODO

## Database & Backend
- [x] Schema DB: tabelle menu_categories, menu_items, reservations
- [x] Seed dati menu iniziali da Google Maps
- [x] API tRPC: CRUD categorie menu (admin)
- [x] API tRPC: CRUD piatti menu (admin)
- [x] API tRPC: lettura pubblica menu
- [x] API tRPC: invio prenotazione con notifica al locale
- [x] Protezione admin con ruolo admin

## Frontend - Struttura
- [x] Tema medievale/fantasy: colori dark + oro/ambra, font tematici
- [x] Navigazione multi-pagina: Home, Menu, link prenotazioni
- [x] Layout globale con header e footer

## Frontend - Home Page
- [x] Hero section con nome ristorante e slogan
- [x] Orario apertura: "apre 19:30"
- [x] Indirizzo: "Via Bernardino da Feltre, 27, Pavia"
- [x] CTA button prenotazione
- [x] Sezione "Chi siamo" / descrizione taverna

## Frontend - Menu Page
- [x] Pagina menu separata con tutte le categorie
- [x] Categorie: Antipasti Medievali, Stuzzicherie Fantasy, Primi/Secondi Piatti Medievali, Pietanze Fantasy, Dolci, Bevande, Pozioni dell'Alchimista, Birre, Liquori, Intrugli Blasfemi
- [x] Visualizzazione piatti con nome, descrizione, prezzo
- [x] Navigazione per categoria

## Frontend - Prenotazioni
- [x] Form: nome, data, ora, numero ospiti, note
- [x] Invio notifica al locale con dettagli prenotazione
- [x] Conferma visiva dopo invio
- [x] Notifica owner tramite sistema notifiche

## Frontend - Contatti & Mappa
- [x] Telefono: +39 0382 151 4493
- [x] Indirizzo: Via Bernardino da Feltre, 27, Pavia
- [x] Orari di apertura
- [x] Google Maps embed

## Frontend - Admin Panel
- [x] Login protetto (solo admin)
- [x] Gestione categorie: aggiungi/modifica/elimina
- [x] Gestione piatti: aggiungi/modifica/elimina
- [x] Visualizzazione prenotazioni ricevute
- [x] UI intuitiva per il personale

## Immagini & Assets
- [x] Immagine hero medievale/fantasy (AI generata)
- [x] Immagini decorative per sezioni
- [x] Nessuna foto reale del locale

## Test & Deploy
- [x] Test vitest per API prenotazioni
- [x] Test vitest per API menu
- [x] Checkpoint finale
