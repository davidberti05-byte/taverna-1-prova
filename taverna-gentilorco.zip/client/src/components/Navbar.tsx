import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Sword } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: "La Taverna" },
    { href: "/menu", label: "Il Menù" },
    { href: "/#prenotazioni", label: "Prenotazioni" },
    { href: "/#contatti", label: "Contatti" },
  ];

  const handleNavClick = (href: string) => {
    setIsOpen(false);
    if (href.startsWith("/#")) {
      const id = href.replace("/#", "");
      if (location !== "/") {
        window.location.href = href;
      } else {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[oklch(0.10_0.02_40/0.97)] backdrop-blur-md border-b border-[oklch(0.28_0.06_60/0.5)]"
          : "bg-gradient-to-b from-[oklch(0.08_0.02_40/0.9)] to-transparent"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 flex items-center justify-center">
              <Sword className="w-6 h-6 text-[oklch(0.72_0.16_70)] group-hover:rotate-12 transition-transform duration-300" />
            </div>
            <div className="flex flex-col leading-none">
              <span
                className="text-[oklch(0.72_0.16_70)] font-bold tracking-widest uppercase"
                style={{ fontFamily: "'Cinzel', serif", fontSize: "0.9rem" }}
              >
                Taverna
              </span>
              <span
                className="text-[oklch(0.92_0.05_75)] tracking-widest uppercase"
                style={{ fontFamily: "'Cinzel', serif", fontSize: "0.65rem", opacity: 0.8 }}
              >
                del Gentilorco
              </span>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              link.href.startsWith("/#") ? (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="nav-link text-[oklch(0.80_0.05_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors"
                >
                  {link.label}
                </button>
              ) : (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`nav-link transition-colors ${
                    location === link.href
                      ? "text-[oklch(0.82_0.14_75)]"
                      : "text-[oklch(0.80_0.05_70)] hover:text-[oklch(0.82_0.14_75)]"
                  }`}
                >
                  {link.label}
                </Link>
              )
            ))}
            <button
              onClick={() => handleNavClick("/#prenotazioni")}
              className="ml-2 px-5 py-2 rounded border border-[oklch(0.72_0.16_70)] text-[oklch(0.72_0.16_70)] hover:bg-[oklch(0.72_0.16_70/0.15)] transition-all duration-200 text-sm"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.08em" }}
            >
              Prenota
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 text-[oklch(0.72_0.16_70)]"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-[oklch(0.10_0.02_40/0.98)] border-t border-[oklch(0.28_0.06_60/0.5)] backdrop-blur-md">
          <div className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              link.href.startsWith("/#") ? (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left py-3 px-2 text-[oklch(0.80_0.05_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors border-b border-[oklch(0.20_0.03_40)]"
                  style={{ fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.08em" }}
                >
                  {link.label}
                </button>
              ) : (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="py-3 px-2 text-[oklch(0.80_0.05_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors border-b border-[oklch(0.20_0.03_40)]"
                  style={{ fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.08em" }}
                >
                  {link.label}
                </Link>
              )
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
