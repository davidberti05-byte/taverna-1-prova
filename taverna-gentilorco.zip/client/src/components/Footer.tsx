import { Link } from "wouter";
import { MapPin, Phone, Clock, Sword } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[oklch(0.08_0.02_40)] border-t border-[oklch(0.28_0.06_60/0.4)] mt-0">
      {/* Ornamental top border */}
      <div className="h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.16_70/0.5)] to-transparent" />

      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Sword className="w-5 h-5 text-[oklch(0.72_0.16_70)]" />
              <h3
                className="text-[oklch(0.72_0.16_70)] text-lg font-bold"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Taverna del Gentilorco
              </h3>
            </div>
            <p className="text-[oklch(0.60_0.05_70)] text-sm leading-relaxed" style={{ fontFamily: "'Crimson Text', serif" }}>
              Un luogo dove il passato medievale incontra la fantasia. Cucina tradizionale, birre artigianali e un'atmosfera unica nel cuore di Pavia.
            </p>
          </div>

          {/* Info */}
          <div className="flex flex-col gap-3">
            <h4
              className="text-[oklch(0.72_0.16_70)] text-sm font-semibold uppercase tracking-widest mb-1"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Informazioni
            </h4>
            <div className="flex items-start gap-2 text-[oklch(0.70_0.05_70)] text-sm">
              <MapPin className="w-4 h-4 text-[oklch(0.72_0.16_70)] mt-0.5 shrink-0" />
              <span>Via Bernardino da Feltre, 27, Pavia</span>
            </div>
            <div className="flex items-center gap-2 text-[oklch(0.70_0.05_70)] text-sm">
              <Phone className="w-4 h-4 text-[oklch(0.72_0.16_70)] shrink-0" />
              <a href="tel:+390382151493" className="hover:text-[oklch(0.82_0.14_75)] transition-colors">
                +39 0382 151 4493
              </a>
            </div>
            <div className="flex items-center gap-2 text-[oklch(0.70_0.05_70)] text-sm">
              <Clock className="w-4 h-4 text-[oklch(0.72_0.16_70)] shrink-0" />
              <span>Apre 19:30</span>
            </div>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-3">
            <h4
              className="text-[oklch(0.72_0.16_70)] text-sm font-semibold uppercase tracking-widest mb-1"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Navigazione
            </h4>
            <div className="flex flex-col gap-2">
              {[
                { href: "/", label: "La Taverna" },
                { href: "/menu", label: "Il Menù" },
                { href: "/#prenotazioni", label: "Prenotazioni" },
                { href: "/#contatti", label: "Contatti" },
              ].map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-[oklch(0.60_0.05_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors text-sm"
                  style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 pt-6 border-t border-[oklch(0.20_0.03_40)] flex flex-col md:flex-row items-center justify-between gap-2">
          <p className="text-[oklch(0.45_0.04_60)] text-xs" style={{ fontFamily: "'Cinzel', serif" }}>
            © {new Date().getFullYear()} Taverna del Gentilorco — Tutti i diritti riservati
          </p>
          <div className="flex items-center gap-1 text-[oklch(0.45_0.04_60)] text-xs">
            <span>✦</span>
            <span style={{ fontFamily: "'IM Fell English', serif", fontStyle: "italic" }}>
              Pavia, Italia
            </span>
            <span>✦</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
