import { useState, useRef } from "react";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Scroll, ChevronDown, ChevronUp } from "lucide-react";

const MENU_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663591088387/N2vCaWTFmgnURAdknEJQq8/menu_bg-XQRXhSuS4XXrwa3EkaVp5K.webp";

function SectionDivider({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-4 my-2">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.16_70/0.4)] to-transparent" />
      {label && (
        <span className="text-[oklch(0.72_0.16_70)] text-xs tracking-widest uppercase px-2" style={{ fontFamily: "'Cinzel', serif" }}>
          ✦ {label} ✦
        </span>
      )}
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.16_70/0.4)] to-transparent" />
    </div>
  );
}

type MenuCategoryWithItems = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  sortOrder: number;
  items: {
    id: number;
    name: string;
    description: string | null;
    price: string | null;
    available: boolean;
  }[];
};

function CategorySection({ category }: { category: MenuCategoryWithItems }) {
  const [expanded, setExpanded] = useState(true);
  const availableItems = category.items.filter(i => i.available);

  return (
    <div className="mb-8">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-4 rounded-t-lg border border-[oklch(0.35_0.08_65/0.4)] bg-[oklch(0.14_0.04_45)] hover:bg-[oklch(0.16_0.04_45)] transition-colors group"
      >
        <div className="flex items-center gap-3">
          <span className="text-[oklch(0.72_0.16_70)] text-lg" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
            {category.name}
          </span>
          {category.description && (
            <span className="hidden md:inline text-[oklch(0.55_0.05_65)] text-sm italic" style={{ fontFamily: "'Crimson Text', serif" }}>
              — {category.description}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[oklch(0.50_0.04_60)] text-sm" style={{ fontFamily: "'Cinzel', serif" }}>
            {availableItems.length} piatti
          </span>
          {expanded
            ? <ChevronUp className="w-4 h-4 text-[oklch(0.72_0.16_70)]" />
            : <ChevronDown className="w-4 h-4 text-[oklch(0.72_0.16_70)]" />
          }
        </div>
      </button>

      {expanded && (
        <div className="border border-t-0 border-[oklch(0.28_0.06_60/0.4)] rounded-b-lg overflow-hidden">
          {availableItems.length === 0 ? (
            <div className="p-6 text-center text-[oklch(0.50_0.04_60)] italic" style={{ fontFamily: "'Crimson Text', serif" }}>
              Nessun piatto disponibile in questa categoria
            </div>
          ) : (
            availableItems.map((item, idx) => (
              <div
                key={item.id}
                className={`flex items-start justify-between gap-4 px-5 py-4 ${
                  idx < availableItems.length - 1
                    ? "border-b border-[oklch(0.20_0.03_40)]"
                    : ""
                } hover:bg-[oklch(0.14_0.03_40/0.5)] transition-colors`}
              >
                <div className="flex-1 min-w-0">
                  <p
                    className="text-[oklch(0.88_0.05_75)] font-semibold mb-0.5"
                    style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.05rem" }}
                  >
                    {item.name}
                  </p>
                  {item.description && (
                    <p
                      className="text-[oklch(0.60_0.04_65)] text-sm leading-relaxed"
                      style={{ fontFamily: "'Crimson Text', serif" }}
                    >
                      {item.description}
                    </p>
                  )}
                </div>
                {item.price && (
                  <div className="shrink-0 mt-0.5">
                    <span className="price-tag">€ {parseFloat(item.price).toFixed(2)}</span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export default function MenuPage() {
  const { data: menu, isLoading } = trpc.menu.getAll.useQuery();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const categoryRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const scrollToCategory = (slug: string) => {
    setActiveCategory(slug);
    const el = categoryRefs.current[slug];
    if (el) {
      const offset = 100;
      const top = el.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-[oklch(0.10_0.02_40)] text-[oklch(0.92_0.05_75)]">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0">
          <img src={MENU_BG} alt="" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.10_0.02_40/0.8)] via-[oklch(0.10_0.02_40/0.6)] to-[oklch(0.10_0.02_40)]" />
        </div>
        <div className="relative z-10 container text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="h-px w-16 bg-[oklch(0.72_0.16_70/0.6)]" />
            <Scroll className="w-5 h-5 text-[oklch(0.72_0.16_70)]" />
            <div className="h-px w-16 bg-[oklch(0.72_0.16_70/0.6)]" />
          </div>
          <h1
            className="text-4xl md:text-6xl font-black text-[oklch(0.72_0.16_70)] mb-4"
            style={{ fontFamily: "'Cinzel Decorative', 'Cinzel', serif" }}
          >
            Il Menù
          </h1>
          <p
            className="text-[oklch(0.70_0.05_70)] text-xl italic max-w-xl mx-auto"
            style={{ fontFamily: "'IM Fell English', serif" }}
          >
            "Antiche ricette medievali e creazioni fantasy per ogni avventuriero"
          </p>
        </div>
      </section>

      {/* Category nav pills */}
      {menu && menu.length > 0 && (
        <div className="sticky top-16 md:top-20 z-40 bg-[oklch(0.10_0.02_40/0.95)] backdrop-blur-md border-b border-[oklch(0.20_0.03_40)] py-3">
          <div className="container">
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide" style={{ scrollbarWidth: "none" }}>
              {menu.map((cat) => (
                <button
                  key={cat.slug}
                  onClick={() => scrollToCategory(cat.slug)}
                  className={`category-pill shrink-0 ${activeCategory === cat.slug ? "active" : ""}`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Menu content */}
      <section className="py-12">
        <div className="container max-w-3xl mx-auto">
          {isLoading ? (
            <div className="flex flex-col gap-6">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 rounded-lg bg-[oklch(0.14_0.03_40)] animate-pulse" />
              ))}
            </div>
          ) : menu && menu.length > 0 ? (
            menu.map((category) => (
              <div
                key={category.id}
                ref={(el) => { categoryRefs.current[category.slug] = el; }}
              >
                <CategorySection category={category as MenuCategoryWithItems} />
              </div>
            ))
          ) : (
            <div className="text-center py-20">
              <p className="text-[oklch(0.55_0.05_65)] text-xl italic" style={{ fontFamily: "'Crimson Text', serif" }}>
                Il menù è in preparazione...
              </p>
            </div>
          )}

          {/* Allergen notice */}
          {menu && menu.length > 0 && (
            <div className="mt-12 p-5 rounded-lg border border-[oklch(0.28_0.06_60/0.3)] bg-[oklch(0.13_0.03_40)]">
              <SectionDivider label="Note" />
              <p className="text-[oklch(0.60_0.04_65)] text-sm text-center mt-3" style={{ fontFamily: "'Crimson Text', serif" }}>
                Per informazioni su allergeni e intolleranze alimentari, si prega di rivolgersi al personale della Taverna.
                I prezzi sono IVA inclusa. Il menù potrebbe subire variazioni stagionali.
              </p>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
