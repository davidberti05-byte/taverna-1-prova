import { useState } from "react";
import { Link } from "wouter";
import { MapPin, Phone, Clock, ChevronDown, Scroll, Sword, Shield, Star } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { MapView } from "@/components/Map";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663591088387/N2vCaWTFmgnURAdknEJQq8/hero_taverna-WkHKq33Y74sSUNRZjZbeBH.webp";
const FOOD_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663591088387/N2vCaWTFmgnURAdknEJQq8/food_illustration-TDzb5LWX2Rc2PFqhQARqMf.webp";
const CASTLE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663591088387/N2vCaWTFmgnURAdknEJQq8/castle_banner-cghPLFEoYqkaNB6uJBv6pb.webp";

function SectionDivider({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-4 my-2">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.16_70/0.4)] to-transparent" />
      {label && (
        <span className="text-[oklch(0.72_0.16_70)] text-xs tracking-widest uppercase px-2" style={{ fontFamily: "'Cinzel', serif" }}>
          ✦ {label} ✦
        </span>
      )}
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[oklch(0.72_0.16_70/0.4)] to-transparent" />
    </div>
  );
}

function ReservationForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "19:30",
    guests: 2,
    notes: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const createReservation = trpc.reservations.create.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      toast.success("Prenotazione inviata! Riceverai conferma dal locale.");
    },
    onError: (err) => {
      toast.error("Errore nell'invio: " + err.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createReservation.mutate({
      ...form,
      guests: Number(form.guests),
    });
  };

  if (submitted) {
    return (
      <div className="text-center py-12 px-6">
        <div className="text-5xl mb-4">🏰</div>
        <h3 className="text-2xl font-bold text-[oklch(0.72_0.16_70)] mb-3" style={{ fontFamily: "'Cinzel', serif" }}>
          Prenotazione Ricevuta!
        </h3>
        <p className="text-[oklch(0.75_0.05_70)] mb-6" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
          La tua richiesta è stata inviata alla Taverna del Gentilorco. Il personale ti contatterà per confermare la prenotazione.
        </p>
        <button
          onClick={() => setSubmitted(false)}
          className="px-6 py-2 border border-[oklch(0.72_0.16_70/0.5)] text-[oklch(0.72_0.16_70)] rounded hover:bg-[oklch(0.72_0.16_70/0.1)] transition-colors text-sm"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          Nuova Prenotazione
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Nome e Cognome *
        </label>
        <input
          type="text"
          required
          placeholder="Il tuo nome..."
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="reservation-input"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Email
        </label>
        <input
          type="email"
          placeholder="tua@email.com"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="reservation-input"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Telefono
        </label>
        <input
          type="tel"
          placeholder="+39 ..."
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="reservation-input"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Numero Ospiti *
        </label>
        <input
          type="number"
          required
          min={1}
          max={50}
          value={form.guests}
          onChange={(e) => setForm({ ...form, guests: parseInt(e.target.value) || 1 })}
          className="reservation-input"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Data *
        </label>
        <input
          type="date"
          required
          value={form.date}
          min={new Date().toISOString().split("T")[0]}
          onChange={(e) => setForm({ ...form, date: e.target.value })}
          className="reservation-input"
          style={{ colorScheme: "dark" }}
        />
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Ora *
        </label>
        <select
          required
          value={form.time}
          onChange={(e) => setForm({ ...form, time: e.target.value })}
          className="reservation-input"
          style={{ colorScheme: "dark" }}
        >
          {["19:30", "20:00", "20:30", "21:00", "21:30", "22:00"].map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1 md:col-span-2">
        <label className="text-[oklch(0.72_0.16_70)] text-sm" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
          Note Speciali
        </label>
        <textarea
          rows={3}
          placeholder="Allergie, occasioni speciali, richieste particolari..."
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          className="reservation-input resize-none"
        />
      </div>

      <div className="md:col-span-2 flex justify-center mt-2">
        <button
          type="submit"
          disabled={createReservation.isPending}
          className="px-10 py-3 bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed gold-glow"
          style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.9rem" }}
        >
          {createReservation.isPending ? "Invio in corso..." : "⚔ Prenota il tuo Posto"}
        </button>
      </div>
    </form>
  );
}

export default function Home() {
  const scrollToReservations = () => {
    document.getElementById("prenotazioni")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-[oklch(0.10_0.02_40)] text-[oklch(0.92_0.05_75)]">
      <Navbar />

      {/* ===== HERO SECTION ===== */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Taverna del Gentilorco"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[oklch(0.08_0.02_40/0.6)] via-[oklch(0.08_0.02_40/0.5)] to-[oklch(0.10_0.02_40)]" />
          <div className="absolute inset-0 bg-gradient-to-r from-[oklch(0.08_0.02_40/0.4)] via-transparent to-[oklch(0.08_0.02_40/0.4)]" />
        </div>

        {/* Hero content */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          {/* Decorative top */}
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="h-px w-16 bg-[oklch(0.72_0.16_70/0.6)]" />
            <span className="text-[oklch(0.72_0.16_70)] text-sm tracking-widest" style={{ fontFamily: "'Cinzel', serif" }}>
              ✦ PAVIA ✦
            </span>
            <div className="h-px w-16 bg-[oklch(0.72_0.16_70/0.6)]" />
          </div>

          <h1
            className="text-5xl md:text-7xl lg:text-8xl font-black mb-4 leading-tight"
            style={{ fontFamily: "'Cinzel Decorative', 'Cinzel', serif" }}
          >
            <span className="shimmer-text">Taverna</span>
            <br />
            <span className="text-[oklch(0.92_0.05_75)] text-3xl md:text-5xl lg:text-6xl font-bold">
              del Gentilorco
            </span>
          </h1>

          <p
            className="text-[oklch(0.80_0.06_70)] text-xl md:text-2xl mb-2 italic"
            style={{ fontFamily: "'IM Fell English', serif" }}
          >
            "Dove il Medioevo incontra la Fantasia"
          </p>

          <div className="flex items-center justify-center gap-4 mt-4 mb-8 text-[oklch(0.70_0.05_70)] text-sm">
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[oklch(0.72_0.16_70)]" />
              <span style={{ fontFamily: "'Cinzel', serif" }}>Apre 19:30</span>
            </div>
            <span className="text-[oklch(0.40_0.04_60)]">|</span>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[oklch(0.72_0.16_70)]" />
              <span>Via Bernardino da Feltre, 27, Pavia</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={scrollToReservations}
              className="px-8 py-3.5 bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-all duration-200 gold-glow"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.9rem" }}
            >
              ⚔ Prenota un Tavolo
            </button>
            <Link
              href="/menu"
              className="px-8 py-3.5 border border-[oklch(0.72_0.16_70/0.6)] text-[oklch(0.82_0.14_75)] rounded hover:bg-[oklch(0.72_0.16_70/0.1)] transition-all duration-200"
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.9rem" }}
            >
              📜 Scopri il Menù
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[oklch(0.72_0.16_70/0.6)] float">
          <ChevronDown className="w-6 h-6" />
        </div>
      </section>

      {/* ===== ABOUT SECTION ===== */}
      <section className="py-20 bg-[oklch(0.10_0.02_40)]">
        <div className="container">
          <SectionDivider label="La Nostra Storia" />
          <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2
                className="text-3xl md:text-4xl font-bold text-[oklch(0.72_0.16_70)] mb-6"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                Un Viaggio nel Tempo
              </h2>
              <p className="text-[oklch(0.78_0.05_70)] mb-4 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
                La Taverna del Gentilorco è un luogo magico nel cuore di Pavia, dove la cucina medievale si fonde con l'universo fantasy. Ogni piatto racconta una storia, ogni bevanda è un'avventura.
              </p>
              <p className="text-[oklch(0.78_0.05_70)] mb-6 leading-relaxed" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
                Dal cinghiale in umido alle pozioni dell'alchimista, dai Cantellus medievali agli intrugli blasfemi: ogni visita è un'esperienza unica che trasporta i nostri ospiti in un'epoca lontana.
              </p>
              <div className="grid grid-cols-3 gap-4 mt-8">
                {[
                  { icon: <Sword className="w-6 h-6" />, label: "Cucina Medievale" },
                  { icon: <Shield className="w-6 h-6" />, label: "Birre Artigianali" },
                  { icon: <Star className="w-6 h-6" />, label: "Atmosfera Fantasy" },
                ].map((item) => (
                  <div key={item.label} className="flex flex-col items-center gap-2 p-4 rounded border border-[oklch(0.28_0.06_60/0.4)] bg-[oklch(0.14_0.03_40)] text-center">
                    <div className="text-[oklch(0.72_0.16_70)]">{item.icon}</div>
                    <span className="text-[oklch(0.70_0.05_70)] text-xs" style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}>
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative rounded-lg overflow-hidden border border-[oklch(0.28_0.06_60/0.4)]">
              <img
                src={FOOD_IMG}
                alt="Cucina medievale della Taverna"
                className="w-full h-80 lg:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.10_0.02_40/0.4)] to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* ===== MENU PREVIEW ===== */}
      <section className="py-16 bg-[oklch(0.12_0.03_40)]">
        <div className="container text-center">
          <SectionDivider label="Il Menù" />
          <h2
            className="text-3xl md:text-4xl font-bold text-[oklch(0.72_0.16_70)] mt-8 mb-4"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            Antiche Ricette & Pietanze Fantasy
          </h2>
          <p className="text-[oklch(0.70_0.05_70)] max-w-2xl mx-auto mb-8" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
            Dal Cinghiale in Umido alle Pozioni dell'Alchimista, passando per gli Hamburger Fantasy e i Dolci Medievali. Un menù per ogni avventuriero.
          </p>
          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {["Antipasti Medievali", "Pietanze Fantasy", "Pozioni dell'Alchimista", "Birre Artigianali", "Dolci"].map((cat) => (
              <span
                key={cat}
                className="category-pill"
              >
                {cat}
              </span>
            ))}
          </div>
          <Link
            href="/menu"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-all duration-200 gold-glow"
            style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.1em", fontSize: "0.9rem" }}
          >
            <Scroll className="w-4 h-4" />
            Consulta il Menù Completo
          </Link>
        </div>
      </section>

      {/* ===== RESERVATIONS SECTION ===== */}
      <section id="prenotazioni" className="py-20 bg-[oklch(0.10_0.02_40)]">
        <div className="container">
          <SectionDivider label="Prenotazioni" />
          <div className="max-w-2xl mx-auto mt-10">
            <h2
              className="text-3xl md:text-4xl font-bold text-[oklch(0.72_0.16_70)] text-center mb-3"
              style={{ fontFamily: "'Cinzel', serif" }}
            >
              Riserva il Tuo Posto
            </h2>
            <p className="text-[oklch(0.70_0.05_70)] text-center mb-8" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
              Compila il modulo per prenotare il tuo tavolo. Il personale della Taverna ti contatterà per confermare.
            </p>
            <div className="p-6 md:p-8 rounded-lg border border-[oklch(0.28_0.06_60/0.4)] bg-[oklch(0.13_0.03_40)]">
              <ReservationForm />
            </div>
            <p className="text-center text-[oklch(0.50_0.04_60)] text-sm mt-4" style={{ fontFamily: "'Crimson Text', serif" }}>
              Oppure chiama direttamente:{" "}
              <a href="tel:+390382151493" className="text-[oklch(0.72_0.16_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors">
                +39 0382 151 4493
              </a>
            </p>
          </div>
        </div>
      </section>

      {/* ===== CONTACTS & MAP ===== */}
      <section id="contatti" className="py-20 bg-[oklch(0.12_0.03_40)]">
        <div className="container">
          <SectionDivider label="Dove Trovarci" />
          <h2
            className="text-3xl md:text-4xl font-bold text-[oklch(0.72_0.16_70)] text-center mt-8 mb-10"
            style={{ fontFamily: "'Cinzel', serif" }}
          >
            La Taverna ti Aspetta
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
            {/* Info */}
            <div className="flex flex-col gap-6">
              <div className="p-6 rounded-lg border border-[oklch(0.28_0.06_60/0.4)] bg-[oklch(0.13_0.03_40)]">
                <h3
                  className="text-lg font-bold text-[oklch(0.72_0.16_70)] mb-4"
                  style={{ fontFamily: "'Cinzel', serif" }}
                >
                  Informazioni
                </h3>
                <div className="flex flex-col gap-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[oklch(0.72_0.16_70)] mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[oklch(0.80_0.05_70)] font-medium">Indirizzo</p>
                      <p className="text-[oklch(0.65_0.05_70)]">Via Bernardino da Feltre, 27, Pavia</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-[oklch(0.72_0.16_70)] mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[oklch(0.80_0.05_70)] font-medium">Telefono</p>
                      <a
                        href="tel:+390382151493"
                        className="text-[oklch(0.65_0.05_70)] hover:text-[oklch(0.82_0.14_75)] transition-colors"
                      >
                        +39 0382 151 4493
                      </a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-[oklch(0.72_0.16_70)] mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[oklch(0.80_0.05_70)] font-medium">Orari</p>
                      <p className="text-[oklch(0.65_0.05_70)]">Apre 19:30</p>
                      <p className="text-[oklch(0.55_0.04_60)] text-sm mt-1">
                        Chiuso il lunedì
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Castle image */}
              <div className="rounded-lg overflow-hidden border border-[oklch(0.28_0.06_60/0.4)] hidden lg:block">
                <img
                  src={CASTLE_IMG}
                  alt="Atmosfera medievale"
                  className="w-full h-48 object-cover"
                />
              </div>
            </div>

            {/* Map */}
            <div className="rounded-lg overflow-hidden border border-[oklch(0.28_0.06_60/0.4)] h-80 lg:h-full min-h-[320px]">
              <MapView
                onMapReady={(map) => {
                  const location = { lat: 45.1846202, lng: 9.1480613 };
                  map.setCenter(location);
                  map.setZoom(16);
                  new google.maps.Marker({
                    position: location,
                    map,
                    title: "Taverna del Gentilorco",
                  });
                }}
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
