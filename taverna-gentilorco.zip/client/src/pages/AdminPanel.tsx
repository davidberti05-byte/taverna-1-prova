import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import {
  Plus, Pencil, Trash2, Check, X, ChevronDown, ChevronUp,
  Calendar, Users, Clock, Sword, BookOpen, Shield
} from "lucide-react";

type Tab = "menu" | "reservations";

// ---- Category Form ----
function CategoryForm({
  initial,
  onSave,
  onCancel,
}: {
  initial?: { id?: number; name: string; slug: string; description?: string | null; sortOrder?: number };
  onSave: (data: { name: string; slug: string; description: string; sortOrder: number }) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [slug, setSlug] = useState(initial?.slug ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [sortOrder, setSortOrder] = useState(initial?.sortOrder ?? 0);

  const autoSlug = (n: string) =>
    n.toLowerCase().replace(/[àáâãäå]/g, "a").replace(/[èéêë]/g, "e").replace(/[ìíîï]/g, "i")
      .replace(/[òóôõö]/g, "o").replace(/[ùúûü]/g, "u").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  return (
    <div className="p-4 bg-[oklch(0.16_0.03_40)] rounded-lg border border-[oklch(0.30_0.06_60/0.4)] flex flex-col gap-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Nome Categoria</label>
          <input
            className="reservation-input"
            value={name}
            onChange={(e) => { setName(e.target.value); if (!initial?.id) setSlug(autoSlug(e.target.value)); }}
            placeholder="es. Antipasti Medievali"
          />
        </div>
        <div>
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Slug (URL)</label>
          <input
            className="reservation-input"
            value={slug}
            onChange={(e) => setSlug(e.target.value)}
            placeholder="es. antipasti-medievali"
          />
        </div>
      </div>
      <div>
        <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Descrizione</label>
        <input
          className="reservation-input"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Breve descrizione della categoria..."
        />
      </div>
      <div>
        <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Ordine</label>
        <input
          type="number"
          className="reservation-input w-24"
          value={sortOrder}
          onChange={(e) => setSortOrder(parseInt(e.target.value) || 0)}
        />
      </div>
      <div className="flex gap-2 justify-end">
        <button onClick={onCancel} className="px-4 py-2 text-sm border border-[oklch(0.30_0.06_60/0.4)] text-[oklch(0.70_0.05_70)] rounded hover:bg-[oklch(0.20_0.03_40)] transition-colors">
          Annulla
        </button>
        <button
          onClick={() => onSave({ name, slug, description, sortOrder })}
          className="px-4 py-2 text-sm bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-colors"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          Salva
        </button>
      </div>
    </div>
  );
}

// ---- Item Form ----
function ItemForm({
  categoryId,
  initial,
  onSave,
  onCancel,
}: {
  categoryId: number;
  initial?: { id?: number; name: string; description?: string | null; price?: string | null; available?: boolean; sortOrder?: number };
  onSave: (data: { categoryId: number; name: string; description: string; price: string; available: boolean; sortOrder: number }) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [price, setPrice] = useState(initial?.price ?? "");
  const [available, setAvailable] = useState(initial?.available ?? true);
  const [sortOrder, setSortOrder] = useState(initial?.sortOrder ?? 0);

  return (
    <div className="p-4 bg-[oklch(0.16_0.03_40)] rounded-lg border border-[oklch(0.30_0.06_60/0.4)] flex flex-col gap-3 mt-2">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="md:col-span-2">
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Nome Piatto *</label>
          <input className="reservation-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome del piatto..." />
        </div>
        <div className="md:col-span-2">
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Descrizione</label>
          <textarea className="reservation-input resize-none" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ingredienti e descrizione..." />
        </div>
        <div>
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Prezzo (€)</label>
          <input type="number" step="0.50" min="0" className="reservation-input" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0.00" />
        </div>
        <div>
          <label className="text-[oklch(0.72_0.16_70)] text-xs mb-1 block" style={{ fontFamily: "'Cinzel', serif" }}>Ordine</label>
          <input type="number" className="reservation-input" value={sortOrder} onChange={(e) => setSortOrder(parseInt(e.target.value) || 0)} />
        </div>
        <div className="flex items-center gap-2">
          <input type="checkbox" id="available" checked={available} onChange={(e) => setAvailable(e.target.checked)} className="w-4 h-4 accent-[oklch(0.72_0.16_70)]" />
          <label htmlFor="available" className="text-[oklch(0.70_0.05_70)] text-sm">Disponibile</label>
        </div>
      </div>
      <div className="flex gap-2 justify-end">
        <button onClick={onCancel} className="px-4 py-2 text-sm border border-[oklch(0.30_0.06_60/0.4)] text-[oklch(0.70_0.05_70)] rounded hover:bg-[oklch(0.20_0.03_40)] transition-colors">
          Annulla
        </button>
        <button
          onClick={() => onSave({ categoryId, name, description, price, available, sortOrder })}
          className="px-4 py-2 text-sm bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-colors"
          style={{ fontFamily: "'Cinzel', serif" }}
        >
          Salva Piatto
        </button>
      </div>
    </div>
  );
}

// ---- Main Admin Panel ----
export default function AdminPanel() {
  const { user, loading, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>("menu");
  const [expandedCats, setExpandedCats] = useState<Record<number, boolean>>({});
  const [addingCategory, setAddingCategory] = useState(false);
  const [editingCategory, setEditingCategory] = useState<number | null>(null);
  const [addingItemToCat, setAddingItemToCat] = useState<number | null>(null);
  const [editingItem, setEditingItem] = useState<number | null>(null);

  const utils = trpc.useUtils();

  const { data: menu, isLoading: menuLoading } = trpc.menu.getAll.useQuery();
  const { data: reservations, isLoading: resLoading } = trpc.reservations.getAll.useQuery(
    { enabled: activeTab === "reservations" } as any
  );

  const createCat = trpc.adminMenu.createCategory.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); setAddingCategory(false); toast.success("Categoria creata!"); },
    onError: (e) => toast.error(e.message),
  });
  const updateCat = trpc.adminMenu.updateCategory.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); setEditingCategory(null); toast.success("Categoria aggiornata!"); },
    onError: (e) => toast.error(e.message),
  });
  const deleteCat = trpc.adminMenu.deleteCategory.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); toast.success("Categoria eliminata!"); },
    onError: (e) => toast.error(e.message),
  });
  const createItem = trpc.adminMenu.createItem.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); setAddingItemToCat(null); toast.success("Piatto aggiunto!"); },
    onError: (e) => toast.error(e.message),
  });
  const updateItem = trpc.adminMenu.updateItem.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); setEditingItem(null); toast.success("Piatto aggiornato!"); },
    onError: (e) => toast.error(e.message),
  });
  const deleteItem = trpc.adminMenu.deleteItem.useMutation({
    onSuccess: () => { utils.menu.getAll.invalidate(); toast.success("Piatto eliminato!"); },
    onError: (e) => toast.error(e.message),
  });
  const updateStatus = trpc.reservations.updateStatus.useMutation({
    onSuccess: () => { utils.reservations.getAll.invalidate(); toast.success("Stato aggiornato!"); },
    onError: (e) => toast.error(e.message),
  });

  const toggleCat = (id: number) => setExpandedCats(prev => ({ ...prev, [id]: !prev[id] }));

  if (loading) {
    return (
      <div className="min-h-screen bg-[oklch(0.10_0.02_40)] flex items-center justify-center">
        <div className="text-[oklch(0.72_0.16_70)] text-xl" style={{ fontFamily: "'Cinzel', serif" }}>
          Caricamento...
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[oklch(0.10_0.02_40)] flex flex-col items-center justify-center gap-6 px-4">
        <Shield className="w-16 h-16 text-[oklch(0.72_0.16_70)]" />
        <h1 className="text-3xl font-bold text-[oklch(0.72_0.16_70)] text-center" style={{ fontFamily: "'Cinzel', serif" }}>
          Accesso Riservato
        </h1>
        <p className="text-[oklch(0.65_0.05_70)] text-center max-w-md" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
          Devi effettuare il login per accedere al pannello di amministrazione della Taverna.
        </p>
        <a
          href={getLoginUrl()}
          className="px-8 py-3 bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-colors gold-glow"
          style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.08em" }}
        >
          Accedi
        </a>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-[oklch(0.10_0.02_40)] flex flex-col items-center justify-center gap-6 px-4">
        <Sword className="w-16 h-16 text-[oklch(0.55_0.22_25)]" />
        <h1 className="text-3xl font-bold text-[oklch(0.55_0.22_25)] text-center" style={{ fontFamily: "'Cinzel', serif" }}>
          Accesso Negato
        </h1>
        <p className="text-[oklch(0.65_0.05_70)] text-center max-w-md" style={{ fontFamily: "'Crimson Text', serif", fontSize: "1.1rem" }}>
          Non hai i permessi necessari per accedere a questa area. Solo gli amministratori della Taverna possono entrare.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[oklch(0.10_0.02_40)] text-[oklch(0.92_0.05_75)]">
      <Navbar />

      <div className="container pt-28 pb-16">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-6 h-6 text-[oklch(0.72_0.16_70)]" />
            <h1 className="text-3xl font-bold text-[oklch(0.72_0.16_70)]" style={{ fontFamily: "'Cinzel', serif" }}>
              Pannello Amministrazione
            </h1>
          </div>
          <p className="text-[oklch(0.60_0.05_70)]" style={{ fontFamily: "'Crimson Text', serif" }}>
            Benvenuto, {user.name}. Gestisci il menù e le prenotazioni della Taverna.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-8 border-b border-[oklch(0.20_0.03_40)]">
          {[
            { id: "menu" as Tab, label: "Gestione Menù", icon: <BookOpen className="w-4 h-4" /> },
            { id: "reservations" as Tab, label: "Prenotazioni", icon: <Calendar className="w-4 h-4" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-5 py-3 text-sm transition-colors border-b-2 -mb-px ${
                activeTab === tab.id
                  ? "border-[oklch(0.72_0.16_70)] text-[oklch(0.72_0.16_70)]"
                  : "border-transparent text-[oklch(0.60_0.05_70)] hover:text-[oklch(0.80_0.05_70)]"
              }`}
              style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* ===== MENU TAB ===== */}
        {activeTab === "menu" && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-[oklch(0.80_0.05_70)]" style={{ fontFamily: "'Cinzel', serif" }}>
                Categorie e Piatti
              </h2>
              <button
                onClick={() => setAddingCategory(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[oklch(0.72_0.16_70)] text-[oklch(0.10_0.02_40)] font-bold rounded hover:bg-[oklch(0.82_0.14_75)] transition-colors text-sm"
                style={{ fontFamily: "'Cinzel', serif" }}
              >
                <Plus className="w-4 h-4" /> Nuova Categoria
              </button>
            </div>

            {addingCategory && (
              <div className="mb-6">
                <CategoryForm
                  onSave={(data) => createCat.mutate(data)}
                  onCancel={() => setAddingCategory(false)}
                />
              </div>
            )}

            {menuLoading ? (
              <div className="flex flex-col gap-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-16 rounded-lg bg-[oklch(0.14_0.03_40)] animate-pulse" />
                ))}
              </div>
            ) : (
              menu?.map((cat) => (
                <div key={cat.id} className="mb-4 border border-[oklch(0.28_0.06_60/0.4)] rounded-lg overflow-hidden">
                  {/* Category header */}
                  {editingCategory === cat.id ? (
                    <div className="p-4 bg-[oklch(0.14_0.03_40)]">
                      <CategoryForm
                        initial={cat}
                        onSave={(data) => updateCat.mutate({ id: cat.id, ...data })}
                        onCancel={() => setEditingCategory(null)}
                      />
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-4 bg-[oklch(0.14_0.04_45)] cursor-pointer"
                      onClick={() => toggleCat(cat.id)}>
                      <div className="flex items-center gap-3">
                        <span className="text-[oklch(0.72_0.16_70)] font-semibold" style={{ fontFamily: "'Cinzel', serif" }}>
                          {cat.name}
                        </span>
                        <span className="text-[oklch(0.50_0.04_60)] text-xs">
                          {cat.items.length} piatti
                        </span>
                      </div>
                      <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setEditingCategory(cat.id)}
                          className="p-1.5 text-[oklch(0.60_0.05_70)] hover:text-[oklch(0.72_0.16_70)] transition-colors"
                          title="Modifica categoria"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Eliminare la categoria "${cat.name}" e tutti i suoi piatti?`)) {
                              deleteCat.mutate({ id: cat.id });
                            }
                          }}
                          className="p-1.5 text-[oklch(0.60_0.05_70)] hover:text-[oklch(0.55_0.22_25)] transition-colors"
                          title="Elimina categoria"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => toggleCat(cat.id)} className="p-1.5 text-[oklch(0.60_0.05_70)]">
                          {expandedCats[cat.id] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Items list */}
                  {expandedCats[cat.id] && (
                    <div className="bg-[oklch(0.11_0.02_40)]">
                      {cat.items.map((item) => (
                        <div key={item.id}>
                          {editingItem === item.id ? (
                            <div className="p-4 border-t border-[oklch(0.20_0.03_40)]">
                              <ItemForm
                                categoryId={cat.id}
                                initial={item}
                                onSave={(data) => updateItem.mutate({ id: item.id, ...data })}
                                onCancel={() => setEditingItem(null)}
                              />
                            </div>
                          ) : (
                            <div className="flex items-start justify-between gap-3 px-5 py-3 border-t border-[oklch(0.18_0.02_40)] hover:bg-[oklch(0.13_0.02_40)] transition-colors">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="text-[oklch(0.85_0.05_75)] text-sm font-medium" style={{ fontFamily: "'Crimson Text', serif" }}>
                                    {item.name}
                                  </span>
                                  {!item.available && (
                                    <span className="text-xs px-1.5 py-0.5 rounded bg-[oklch(0.55_0.22_25/0.2)] text-[oklch(0.70_0.15_25)]">
                                      Non disponibile
                                    </span>
                                  )}
                                </div>
                                {item.description && (
                                  <p className="text-[oklch(0.55_0.04_60)] text-xs mt-0.5 line-clamp-1" style={{ fontFamily: "'Crimson Text', serif" }}>
                                    {item.description}
                                  </p>
                                )}
                              </div>
                              <div className="flex items-center gap-3 shrink-0">
                                {item.price && (
                                  <span className="price-tag text-sm">€{parseFloat(item.price as string).toFixed(2)}</span>
                                )}
                                <button
                                  onClick={() => setEditingItem(item.id)}
                                  className="p-1 text-[oklch(0.55_0.04_60)] hover:text-[oklch(0.72_0.16_70)] transition-colors"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`Eliminare "${item.name}"?`)) {
                                      deleteItem.mutate({ id: item.id });
                                    }
                                  }}
                                  className="p-1 text-[oklch(0.55_0.04_60)] hover:text-[oklch(0.55_0.22_25)] transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}

                      {/* Add item */}
                      {addingItemToCat === cat.id ? (
                        <div className="p-4 border-t border-[oklch(0.20_0.03_40)]">
                          <ItemForm
                            categoryId={cat.id}
                            onSave={(data) => createItem.mutate(data)}
                            onCancel={() => setAddingItemToCat(null)}
                          />
                        </div>
                      ) : (
                        <button
                          onClick={() => setAddingItemToCat(cat.id)}
                          className="w-full flex items-center gap-2 justify-center py-3 border-t border-[oklch(0.20_0.03_40)] text-[oklch(0.55_0.05_65)] hover:text-[oklch(0.72_0.16_70)] hover:bg-[oklch(0.13_0.03_40)] transition-colors text-sm"
                          style={{ fontFamily: "'Cinzel', serif", letterSpacing: "0.05em" }}
                        >
                          <Plus className="w-4 h-4" /> Aggiungi Piatto
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* ===== RESERVATIONS TAB ===== */}
        {activeTab === "reservations" && (
          <div>
            <h2 className="text-xl font-bold text-[oklch(0.80_0.05_70)] mb-6" style={{ fontFamily: "'Cinzel', serif" }}>
              Prenotazioni Ricevute
            </h2>

            {resLoading ? (
              <div className="flex flex-col gap-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-20 rounded-lg bg-[oklch(0.14_0.03_40)] animate-pulse" />
                ))}
              </div>
            ) : reservations && reservations.length > 0 ? (
              <div className="flex flex-col gap-3">
                {reservations.map((res) => (
                  <div
                    key={res.id}
                    className={`p-5 rounded-lg border transition-colors ${
                      res.status === "confirmed"
                        ? "border-[oklch(0.55_0.18_145/0.4)] bg-[oklch(0.13_0.03_145/0.3)]"
                        : res.status === "cancelled"
                        ? "border-[oklch(0.55_0.22_25/0.3)] bg-[oklch(0.13_0.02_25/0.2)]"
                        : "border-[oklch(0.28_0.06_60/0.4)] bg-[oklch(0.13_0.03_40)]"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-[oklch(0.85_0.05_75)] font-semibold" style={{ fontFamily: "'Cinzel', serif" }}>
                            {res.name}
                          </h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            res.status === "confirmed"
                              ? "bg-[oklch(0.55_0.18_145/0.2)] text-[oklch(0.70_0.18_145)]"
                              : res.status === "cancelled"
                              ? "bg-[oklch(0.55_0.22_25/0.2)] text-[oklch(0.70_0.15_25)]"
                              : "bg-[oklch(0.72_0.16_70/0.15)] text-[oklch(0.72_0.16_70)]"
                          }`} style={{ fontFamily: "'Cinzel', serif" }}>
                            {res.status === "confirmed" ? "Confermata" : res.status === "cancelled" ? "Annullata" : "In attesa"}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-[oklch(0.65_0.05_65)]">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-[oklch(0.72_0.16_70)]" />
                            <span>{res.date}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-[oklch(0.72_0.16_70)]" />
                            <span>{res.time}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Users className="w-3.5 h-3.5 text-[oklch(0.72_0.16_70)]" />
                            <span>{res.guests} ospiti</span>
                          </div>
                          {res.phone && (
                            <a href={`tel:${res.phone}`} className="flex items-center gap-1 hover:text-[oklch(0.72_0.16_70)] transition-colors">
                              📞 {res.phone}
                            </a>
                          )}
                          {res.email && (
                            <a href={`mailto:${res.email}`} className="flex items-center gap-1 hover:text-[oklch(0.72_0.16_70)] transition-colors">
                              ✉ {res.email}
                            </a>
                          )}
                        </div>
                        {res.notes && (
                          <p className="mt-2 text-sm text-[oklch(0.60_0.04_65)] italic" style={{ fontFamily: "'Crimson Text', serif" }}>
                            Note: {res.notes}
                          </p>
                        )}
                      </div>
                      {res.status === "pending" && (
                        <div className="flex gap-2 shrink-0">
                          <button
                            onClick={() => updateStatus.mutate({ id: res.id, status: "confirmed" })}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-[oklch(0.55_0.18_145/0.2)] text-[oklch(0.70_0.18_145)] border border-[oklch(0.55_0.18_145/0.4)] rounded hover:bg-[oklch(0.55_0.18_145/0.3)] transition-colors text-sm"
                          >
                            <Check className="w-3.5 h-3.5" /> Conferma
                          </button>
                          <button
                            onClick={() => updateStatus.mutate({ id: res.id, status: "cancelled" })}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-[oklch(0.55_0.22_25/0.15)] text-[oklch(0.70_0.15_25)] border border-[oklch(0.55_0.22_25/0.3)] rounded hover:bg-[oklch(0.55_0.22_25/0.25)] transition-colors text-sm"
                          >
                            <X className="w-3.5 h-3.5" /> Annulla
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Calendar className="w-12 h-12 text-[oklch(0.40_0.04_60)] mx-auto mb-4" />
                <p className="text-[oklch(0.55_0.04_60)] text-lg italic" style={{ fontFamily: "'Crimson Text', serif" }}>
                  Nessuna prenotazione ricevuta ancora.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
