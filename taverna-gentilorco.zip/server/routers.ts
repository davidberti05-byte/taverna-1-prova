import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getAllMenuWithItems,
  getAllCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory,
  getItemsByCategory,
  getItemById,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
  createReservation,
  getAllReservations,
  updateReservationStatus,
} from "./db";
import { notifyOwner } from "./_core/notification";
import { ENV } from "./_core/env";
import { getDb } from "./db";
import { menuCategories, menuItems } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Accesso riservato agli amministratori" });
  }
  return next({ ctx });
});

// Email notification helper for reservations
async function sendReservationEmail(reservation: {
  name: string;
  email?: string | null;
  phone?: string | null;
  date: string;
  time: string;
  guests: number;
  notes?: string | null;
}) {
  const restaurantEmail = ENV.restaurantEmail;
  const content = `
Nuova prenotazione ricevuta dalla Taverna del Gentilorco:

Nome: ${reservation.name}
Data: ${reservation.date}
Ora: ${reservation.time}
Numero ospiti: ${reservation.guests}
${reservation.email ? `Email cliente: ${reservation.email}` : ""}
${reservation.phone ? `Telefono cliente: ${reservation.phone}` : ""}
${reservation.notes ? `Note: ${reservation.notes}` : ""}

${restaurantEmail ? `Notifica inviata a: ${restaurantEmail}` : ""}
Per gestire le prenotazioni, accedi al pannello admin del sito: /admin
  `.trim();

  await notifyOwner({
    title: `🏰 Nuova Prenotazione - ${reservation.name} (${reservation.guests} ospiti) - ${reservation.date} ore ${reservation.time}`,
    content,
  });
}

// Seed data for initial menu
async function seedMenuIfEmpty() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select().from(menuCategories).limit(1);
  if (existing.length > 0) return;

  const categories = [
    { name: "Antipasti Medievali", slug: "antipasti-medievali", description: "Prelibatezze dell'antica cucina medievale", sortOrder: 1 },
    { name: "Stuzzicherie Fantasy", slug: "stuzzicherie-fantasy", description: "Bocconcini magici per stuzzicare l'appetito", sortOrder: 2 },
    { name: "Primi Piatti Medievali", slug: "primi-piatti-medievali", description: "Zuppe e paste della tradizione medievale", sortOrder: 3 },
    { name: "Secondi Piatti Medievali", slug: "secondi-piatti-medievali", description: "Carni e pietanze della corte medievale", sortOrder: 4 },
    { name: "Pietanze Fantasy", slug: "pietanze-fantasy", description: "Hamburger e creazioni fantasy dell'Orco", sortOrder: 5 },
    { name: "Dolci", slug: "dolci", description: "Dolci medievali e fantasy per chiudere in bellezza", sortOrder: 6 },
    { name: "Bevande", slug: "bevande", description: "Vini, sidri e bevande della taverna", sortOrder: 7 },
    { name: "Pozioni dell'Alchimista", slug: "pozioni-alchimista", description: "Cocktail e misture magiche preparate dall'alchimista", sortOrder: 8 },
    { name: "Birre", slug: "birre", description: "Birre alla spina e artigianali in bottiglia", sortOrder: 9 },
    { name: "Liquori", slug: "liquori", description: "Liquori artigianali, amari e grappe", sortOrder: 10 },
    { name: "Intrugli Blasfemi", slug: "intrugli-blasfemi", description: "Cocktail proibiti e misture oscure", sortOrder: 11 },
  ];

  for (const cat of categories) {
    await db.insert(menuCategories).values(cat);
  }

  const catRows = await db.select().from(menuCategories);
  const catMap = Object.fromEntries(catRows.map(c => [c.slug, c.id]));

  const items = [
    // Antipasti Medievali
    { categoryId: catMap["antipasti-medievali"], name: "Salumi scelti del Contadino", description: "Crudo di Parma DOP, speck del Trentino Alto Adige IGP, coppa di Parma IGP, salame piacentino DOP e lardo Patanegra, serviti con pane fatto in Taverna", price: "12.00", sortOrder: 1 },
    { categoryId: catMap["antipasti-medievali"], name: "Formaggi del Giullare con marmella", description: "Selezione di formaggi serviti con marmellata della Taverna e miele millefiori con noce moscata", price: "14.00", sortOrder: 2 },
    { categoryId: catMap["antipasti-medievali"], name: "Saluto d'Oriente", description: "Bruschette di pane della Taverna con pancetta piacentina DOP scottata al forno e humus di ceci", price: "6.50", sortOrder: 3 },
    { categoryId: catMap["antipasti-medievali"], name: "Saluto di Corte", description: "Bruschette di pane della Taverna con crudo di Parma DOP e composta di fichi secchi e senape", price: "6.50", sortOrder: 4 },
    { categoryId: catMap["antipasti-medievali"], name: "Saluto dei Campi", description: "Bruschette di pane della Taverna con lardo di razza Iberica Patanegra e salsa di miele e noci", price: "6.50", sortOrder: 5 },
    // Stuzzicherie Fantasy
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Non-Unici Anelli", description: "Anelli di cipolla rossa in pastella dell'Orco", price: "5.00", sortOrder: 1 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Loot del Ladro", description: "Bocconi di pollo fatti in Taverna con impanatura croccante", price: "5.00", sortOrder: 2 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Unghie di Gigante", description: "Patatine fritte attentamente selezionate dal Gentilorco", price: "5.50", sortOrder: 3 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Foglie Benefiche", description: "Foglie di salvia fritta in pastella dell'Orco", price: "5.00", sortOrder: 4 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Lingua di Troll", description: "Peperoni Cruschi di Senise IGP croccanti", price: "5.50", sortOrder: 5 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Orecchie di Elfo Croccanti", description: "Nachos ricoperti di formaggio fuso con ricetta originale della Taverna e salsa barbecue dell'Orco", price: "5.00", sortOrder: 6 },
    { categoryId: catMap["stuzzicherie-fantasy"], name: "Forza della Trinità", description: "Tris di salse artigianali preparate in Taverna", price: "1.00", sortOrder: 7 },
    // Primi Piatti Medievali
    { categoryId: catMap["primi-piatti-medievali"], name: "Verde Contea (su richiesta anche in versione vegana)", description: "Vellutata di legumi con pancetta piacentina DOP croccante e crostini di pane casereccio all'olio d'oliva extravergine. Ricetta storica rielaborata dagli scritti medievali di Maestro Martino", price: "12.00", sortOrder: 1 },
    { categoryId: catMap["primi-piatti-medievali"], name: "Salvia nel Piatto", description: "Maltagliati all'uovo con farina di grano saraceno fatti a mano in Taverna e conditi con burro, salvia e pecorino romano DOP", price: "12.00", sortOrder: 2 },
    { categoryId: catMap["primi-piatti-medievali"], name: "Lucrezia Borgia", description: "Pasta fresca all'uovo fatta in Taverna condita con ragù bianco di manzo e pancetta piacentina DOP. Piatto rinascimentale proposto in occasione dei 500 anni dalla Battaglia di Pavia, estratto dal ricettario di Mastro Zefirano del 1501", price: "13.00", sortOrder: 3 },
    { categoryId: catMap["primi-piatti-medievali"], name: "Festa del Raccolto", description: "Zuppa di farro, orzo, lenticchie, ceci e grano saraceno con cavolo nero e gocce di gorgonzola DOP", price: "14.00", sortOrder: 4 },
    // Secondi Piatti Medievali
    { categoryId: catMap["secondi-piatti-medievali"], name: "Glifo a Spirale", description: "Salsiccia speziata con contorno di scarola allo zenzero, cipolla caramellata all'aceto balsamico, servita con fette di pane della Taverna", price: "17.00", sortOrder: 1 },
    { categoryId: catMap["secondi-piatti-medievali"], name: "Antica Pietanza", description: "Antica ricetta Cosciotto di pollo alla birra con contorno di radicchio caramellato e salsa ai ceci, servito con fette di pane della Taverna", price: "18.00", sortOrder: 2 },
    { categoryId: catMap["secondi-piatti-medievali"], name: "Lauto Banchetto", description: "Cinghiale in umido servito con fette di polenta taragna", price: "20.00", sortOrder: 3 },
    { categoryId: catMap["secondi-piatti-medievali"], name: "Piede di Porco (disponibilità limitata)", description: "Stinco di maiale italiano speziato e cotto in Taverna a bassa temperatura per 24 ore e successivamente dorato al forno, accompagnato da crauti alle bacche di ginepro", price: "21.00", sortOrder: 4 },
    // Pietanze Fantasy
    { categoryId: catMap["pietanze-fantasy"], name: "Focus Arcano", description: "Buns della Taverna con sesamo, hamburger di manzo, insalata, pomodoro ramato, cheddar, maionese e ketchup con contorno di patatine fritte", price: "14.00", sortOrder: 1 },
    { categoryId: catMap["pietanze-fantasy"], name: "Palla di fuoco", description: "Buns della Taverna con sesamo, hamburger di manzo, rucola, scaglie di Grana Padano, pomodoro ramato, cheddar e tabasco con contorno di patatine fritte", price: "15.00", sortOrder: 2 },
    { categoryId: catMap["pietanze-fantasy"], name: "Nido di Cocatrice", description: "Buns della Taverna con sesamo, hamburger di manzo, insalata, pomodoro ramato, cheddar, cipolla, uovo all'occhio di bue e salsa barbecue dell'Orco con contorno di patatine fritte", price: "15.00", sortOrder: 3 },
    { categoryId: catMap["pietanze-fantasy"], name: "Tana dell'Unicorno", description: "Buns della Taverna con sesamo, hamburger di manzo, radicchio, pancetta piacentina DOP, provola, pomodoro cuore di bue e maionese al curry con contorno di patatine fritte", price: "15.00", sortOrder: 4 },
    { categoryId: catMap["pietanze-fantasy"], name: "Equilibrio Mistico (non modificabile)", description: "Buns della Taverna con sesamo, hamburger di manzo, cipolla caramellata, salsa di scalogno agrodolce, salsa barbecue dell'Orco, maionese all'aglio nero, cavolo bianco e viola con contorno di patatine fritte", price: "15.00", sortOrder: 5 },
    { categoryId: catMap["pietanze-fantasy"], name: "Doppio Rancio", description: "Buns della Taverna con sesamo, doppio hamburger di manzo, doppio cheddar, doppio pomodoro ramato, insalata, cipolla caramellata al balsamico di Modena e maionese all'aglio nero con contorno di patatine fritte", price: "20.00", sortOrder: 6 },
    { categoryId: catMap["pietanze-fantasy"], name: "La Grande Caccia", description: "Buns della Taverna con sesamo, hamburger di cacciagione, mela verde, cheddar, insalata, salsa Worcestershire salsa allo scalogno con contorno di patatine fritte", price: "16.00", sortOrder: 7 },
    { categoryId: catMap["pietanze-fantasy"], name: "Patto con l'Antico", description: "Buns della Taverna con sesamo, Pulled-Pork cotto in Taverna per 24 ore a bassa temperatura, insalata, pomodoro ramato, cheddar, cipolla caramellata e salsa barbecue dell'Orco con contorno di patatine fritte", price: "15.00", sortOrder: 8 },
    // Dolci
    { categoryId: catMap["dolci"], name: "Boss Finale", description: "Torta al cioccolato con mousse e ganache al cioccolato e granella di pistacchio", price: "6.00", sortOrder: 1 },
    { categoryId: catMap["dolci"], name: "Scambio Equivalente", description: "Cheesecake al caramello salato e granella di mandorle su un letto di crumble servita al bicchiere", price: "7.00", sortOrder: 2 },
    { categoryId: catMap["dolci"], name: "Riso alla Turchesca", description: "Torta a base di chicchi riso dolce con scorza di limone. Dolce rinascimentale proposto in occasione dei 500 anni dalla Battaglia di Pavia, estratto dal ricettario di Cristoforo Messisburgo del 1557", price: "5.50", sortOrder: 3 },
    { categoryId: catMap["dolci"], name: "Lingotto d'Oro", description: "Torta di mele con spezie e cannella, accompagnata da panna montata", price: "6.00", sortOrder: 4 },
    { categoryId: catMap["dolci"], name: "Pandolce del Viandante", description: "Cantellus (ovvero Cantucci di antica ricetta toscana medievale) con aggiunta di mandorle, accompagnato da calice di idromele a scelta tra monastico, speziato e di bosco", price: "8.00", sortOrder: 5 },
    { categoryId: catMap["dolci"], name: "Pandolce dell'Eroe", description: "Cantellus (ovvero Cantucci di antica ricetta toscana medievale) con aggiunta di mandorle, accompagnato da calice di idromele barrique", price: "10.00", sortOrder: 6 },
    // Bevande
    { categoryId: catMap["bevande"], name: "Fiaschetta Estus", description: "Bevanda nota come 'Spritz' rivisitata dal Gentilorco composta da Sidro di Mele e Aperol", price: "6.50", sortOrder: 1 },
    { categoryId: catMap["bevande"], name: "Sidro di mele alla spina", description: "Bevanda alcolica frizzante a base di succo di mele bio del Trentino, con menta e fiori di sambuco di agricoltura biologica. 7%", price: "6.50", sortOrder: 2 },
    { categoryId: catMap["bevande"], name: "Incantesimo Rituale", description: "Leggende narrano che questa bevanda, anche nota come 'Gin Lemon', cambi colore mentre la si compone. Prova tu stesso a eseguire il rituale", price: "9.00", sortOrder: 3 },
    { categoryId: catMap["bevande"], name: "Idromele monastico", description: "Liquore al miele millefiori prodotto dai monaci benedettini. 11%", price: "6.00", sortOrder: 4 },
    { categoryId: catMap["bevande"], name: "Idromele speziato", description: "Liquore al miele millefiori con estratto di erbe e spezie. Medaglia d'oro Apimondia. 13,5%", price: "6.00", sortOrder: 5 },
    { categoryId: catMap["bevande"], name: "Idromele di bosco", description: "Liquore al miele di montagna (melata di alta qualità). Doppia medaglia d'oro Mazor Cup. 13,5%", price: "6.00", sortOrder: 6 },
    { categoryId: catMap["bevande"], name: "Idromele barrique", description: "Liquore barricato al miele d'acacia dal delicato aroma di cognac e con un retrogusto di vaniglia e cioccolato. Premiato come miglior idromele al mondo. 13,5%", price: "8.00", sortOrder: 7 },
    { categoryId: catMap["bevande"], name: "Ippocrasso", description: "Vino rosso di antica ricetta medievale, dal sapore dolce e speziato. 12,5%", price: "6.50", sortOrder: 8 },
    { categoryId: catMap["bevande"], name: "Bonarda", description: "Vino rosso frizzante Bonarda d'Oltrepò Pavese. DOC 12,5%", price: "18.00", sortOrder: 9 },
    { categoryId: catMap["bevande"], name: "Priolino", description: "Vino rosso fermo d'Oltrepò Pavese IGT (Croatina, Uva rara e Pinot nero). 13%", price: "18.00", sortOrder: 10 },
    // Pozioni dell'Alchimista
    { categoryId: catMap["pozioni-alchimista"], name: "Pozione della Forza", description: "Cocktail energizzante a base di rum speziato, succo di lime, zenzero e miele", price: "8.00", sortOrder: 1 },
    { categoryId: catMap["pozioni-alchimista"], name: "Elisir di Lunga Vita", description: "Gin, acqua tonica, cetriolo e erbe aromatiche della Taverna", price: "8.00", sortOrder: 2 },
    { categoryId: catMap["pozioni-alchimista"], name: "Filtro d'Amore", description: "Vodka, liquore ai frutti di bosco, succo di mirtillo e limone", price: "8.00", sortOrder: 3 },
    { categoryId: catMap["pozioni-alchimista"], name: "Nebbia del Druido", description: "Whisky torbato, miele di castagno, limone e ghiaccio secco per l'effetto nebbia", price: "10.00", sortOrder: 4 },
    // Birre
    { categoryId: catMap["birre"], name: "Birra dell'Orco (size umano)", description: "Birra artigianale della Taverna - pinta 0,5L", price: "6.00", sortOrder: 1 },
    { categoryId: catMap["birre"], name: "Litro di Birra Affumicata", description: "Birra artigianale affumicata - formato da 1 litro", price: "12.00", sortOrder: 2 },
    { categoryId: catMap["birre"], name: "Birre Artigianali in Bottiglia", description: "Selezione di birre artigianali italiane e straniere in bottiglia - chiedere disponibilità", price: "6.00", sortOrder: 3 },
    // Liquori
    { categoryId: catMap["liquori"], name: "Liquori Artigianali della Taverna", description: "Selezione di liquori artigianali prodotti con ricette antiche - chiedere disponibilità", price: "5.00", sortOrder: 1 },
    { categoryId: catMap["liquori"], name: "Amari e Grappe Artigianali", description: "Selezione di amari e grappe artigianali italiane - chiedere disponibilità", price: "5.00", sortOrder: 2 },
    // Intrugli Blasfemi
    { categoryId: catMap["intrugli-blasfemi"], name: "L'Intruglio Proibito", description: "Miscela oscura di rum invecchiato, liquore alle erbe, succo di melograno e spezie segrete", price: "9.00", sortOrder: 1 },
    { categoryId: catMap["intrugli-blasfemi"], name: "Sangue del Vampiro", description: "Vodka, succo di pomodoro piccante, limone, salsa Worcestershire e tabasco", price: "9.00", sortOrder: 2 },
    { categoryId: catMap["intrugli-blasfemi"], name: "Veleno dell'Assassino", description: "Tequila, triple sec, succo di lime, sale e pepe nero - servito con bordo salato", price: "9.00", sortOrder: 3 },
  ];

  for (const item of items) {
    if (item.categoryId) {
      await db.insert(menuItems).values({
        ...item,
        price: item.price as any,
        available: true,
      });
    }
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Public menu endpoints
  menu: router({
    getAll: publicProcedure.query(async () => {
      await seedMenuIfEmpty();
      return getAllMenuWithItems();
    }),
    getCategories: publicProcedure.query(async () => {
      await seedMenuIfEmpty();
      return getAllCategories();
    }),
  }),

  // Admin menu management
  adminMenu: router({
    // Categories
    createCategory: adminProcedure
      .input(z.object({
        name: z.string().min(1),
        slug: z.string().min(1),
        description: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return createCategory(input);
      }),

    updateCategory: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        slug: z.string().min(1).optional(),
        description: z.string().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return updateCategory(id, data);
      }),

    deleteCategory: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteCategory(input.id);
        return { success: true };
      }),

    // Items
    createItem: adminProcedure
      .input(z.object({
        categoryId: z.number(),
        name: z.string().min(1),
        description: z.string().optional(),
        price: z.string().optional(),
        available: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return createMenuItem(input as any);
      }),

    updateItem: adminProcedure
      .input(z.object({
        id: z.number(),
        categoryId: z.number().optional(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        available: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return updateMenuItem(id, data as any);
      }),

    deleteItem: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteMenuItem(input.id);
        return { success: true };
      }),
  }),

  // Reservations
  reservations: router({
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1, "Il nome è obbligatorio"),
        email: z.string().email("Email non valida").optional().or(z.literal("")),
        phone: z.string().optional(),
        date: z.string().min(1, "La data è obbligatoria"),
        time: z.string().min(1, "L'ora è obbligatoria"),
        guests: z.number().min(1).max(50),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const reservation = await createReservation({
          ...input,
          email: input.email || null,
          phone: input.phone || null,
          notes: input.notes || null,
        });

        // Send email notification to restaurant owner
        await sendReservationEmail(input);

        return reservation;
      }),

    getAll: adminProcedure.query(async () => {
      return getAllReservations();
    }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "cancelled"]),
      }))
      .mutation(async ({ input }) => {
        await updateReservationStatus(input.id, input.status);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
