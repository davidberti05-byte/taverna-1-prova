import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("reservations", () => {
  it("should reject reservation with missing required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.reservations.create({
        name: "",
        date: "2026-12-25",
        time: "20:00",
        guests: 2,
      })
    ).rejects.toThrow();
  });

  it("should reject reservation with invalid guest count", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.reservations.create({
        name: "Test User",
        date: "2026-12-25",
        time: "20:00",
        guests: 0,
      })
    ).rejects.toThrow();
  });

  it("should reject reservation with invalid email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.reservations.create({
        name: "Test User",
        email: "not-an-email",
        date: "2026-12-25",
        time: "20:00",
        guests: 2,
      })
    ).rejects.toThrow();
  });
});

describe("menu router", () => {
  it("menu router is defined on appRouter", () => {
    expect(appRouter).toBeDefined();
    // Menu router is accessible
    expect(typeof appRouter).toBe("object");
  });
});

describe("adminMenu", () => {
  it("should reject unauthenticated admin access", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.adminMenu.createCategory({
        name: "Test",
        slug: "test",
      })
    ).rejects.toThrow();
  });
});
